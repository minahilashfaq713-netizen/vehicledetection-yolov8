# weights/

Place your trained model file here as **`best.pt`**.

This notebook trains the model with:

```python
model = YOLO('yolov8n.pt')
model.train(data=data_yaml_path, epochs=5, imgsz=640)
```

After training, Ultralytics saves the best checkpoint at:

```
runs/detect/train/weights/best.pt
```

Copy that file into this folder so the path in `app.py` resolves to:

```
Deployment/weights/best.pt
```

### If the file is too large for a normal `git push`

GitHub blocks files over 100 MB (a fine-tuned YOLOv8n is usually only
~6 MB, so this likely won't be an issue, but if you used a larger
backbone such as `yolov8m`/`yolov8l`/`yolov8x`):

1. Install [Git LFS](https://git-lfs.com/): `git lfs install`
2. Track the weights: `git lfs track "*.pt"`
3. Commit `.gitattributes`, then commit and push `best.pt` as usual.

Alternatively, host the weights externally (e.g. a GitHub Release,
Hugging Face Hub, or Google Drive) and download them at app startup —
see the "Loading weights from a URL instead" section in `README.md`.
